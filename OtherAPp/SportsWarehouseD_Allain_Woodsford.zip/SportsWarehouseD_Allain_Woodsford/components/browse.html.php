<?php
    include "components/siteMainSubheading.php";
?>
<?php include "components/products.html.php" ?>