<section class="site-main__checkout__phases ">
            <a href="cart.php" rel="noreferrer" aria-label="Review cart order"><i class="fa-solid fa-cart-shopping fa-xl is-mr-5 is-blue"></i>1.Cart</a>
            <a href="shipping.php" rel="noreferrer" aria-label="Fill-out shipping details"><i class="fa-solid fa-truck fa-xl is-mr-5 is-blue"></i>2.Shipping</a>
            <a href="checkout.php" rel="noreferrer" aria-label="Finalize and fill-out payment details"><i class="fa-solid fa-credit-card fa-xl is-mr-5 is-blue"></i>3.Payment</a>
</section>