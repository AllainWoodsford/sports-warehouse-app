<div class="site-main__header">
    <h2 class="site-main__header-subheading"><?=$heading?></h2>
</div>