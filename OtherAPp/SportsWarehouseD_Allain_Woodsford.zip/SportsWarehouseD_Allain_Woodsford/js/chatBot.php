<script src="https://cdn.botpress.cloud/webchat/v1/inject.js"></script>
<script src="https://mediafiles.botpress.cloud/c93ff294-1f8d-4f69-90a0-52fa8157e6b8/webchat/config.js" defer></script>